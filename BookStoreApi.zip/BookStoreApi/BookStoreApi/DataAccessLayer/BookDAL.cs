﻿using System;
using System.Collections.Generic;
using System.Linq;
using BookStoreApi.Models;

namespace BookStoreApi.DataAccessLayer
{
    public class BookDAL
    {
        private static List<Book> _books = new List<Book>
        {
            new Book { Id = 1, Title = "Book 1", Author = "Author A", Genre = "Fiction", ImageUrl = "https://example.com/book1.jpg", Price = 1000 },
            new Book { Id = 2, Title = "Book 2", Author = "Author B", Genre = "Non-fiction", ImageUrl = "https://example.com/book2.jpg", Price = 15000 },
            new Book { Id = 3, Title = "Book 3", Author = "Author A", Genre = "Science", ImageUrl = "https://example.com/book3.jpg", Price = 5000 },
            new Book { Id = 4, Title = "Book 4", Author = "Author C", Genre = "Mystery", ImageUrl = "https://example.com/book4.jpg", Price = 8000 }
        };

        public List<Book> GetBooks()
        {
            return _books;
        }

        public Book GetBook(int id)
        {
            return _books.Find(b => b.Id == id);
        }

        public void AddBook(Book book)
        {
            try
            {
                book.Id = _books.Max(b => b.Id) + 1; // Simulate auto-increment ID
            }
            catch (InvalidOperationException)
            {
                book.Id = 1; // If _books is empty, start with ID 1
            }

            _books.Add(book);
        }

        public void UpdateBook(Book book)
        {
            var existingBook = _books.Find(b => b.Id == book.Id);
            if (existingBook != null)
            {
                existingBook.Title = book.Title;
                existingBook.Author = book.Author;
                existingBook.Genre = book.Genre;
                existingBook.Price = book.Price;
                existingBook.ImageUrl = book.ImageUrl;
            }
        }

        public void DeleteBook(int id)
        {
            var book = _books.Find(b => b.Id == id);
            if (book != null)
            {
                _books.Remove(book);
            }
        }
    }
}
