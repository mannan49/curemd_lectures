using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using BookStoreApi.Models;
using BookStoreApi.BusinessLogicLayer;

namespace BookStoreApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private BookBL _bookBL;

        public BooksController()
        {
            _bookBL = new BookBL();  // Initialize the BL instance
        }

        // GET: api/books
        [HttpGet]
        public ActionResult<IEnumerable<Book>> Get()
        {
            return _bookBL.GetBooks();
        }

        // GET: api/books/{id}
        [HttpGet("{id}")]
        public ActionResult<Book> Get(int id)
        {
            var book = _bookBL.GetBook(id);
            if (book == null)
            {
                return NotFound();
            }
            return book;
        }

        // POST: api/books
        [HttpPost]
        public ActionResult<Book> Post(Book book)
        {
            _bookBL.AddBook(book);
            return CreatedAtAction(nameof(Get), new { id = book.Id }, book);
        }

        // PUT: api/books/{id}
        [HttpPut("{id}")]
        public IActionResult Put(int id, Book book)
        {
            if (id != book.Id)
            {
                return BadRequest();
            }

            _bookBL.UpdateBook(book);
            return NoContent();
        }

        // DELETE: api/books/{id}
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var book = _bookBL.GetBook(id);
            if (book == null)
            {
                return NotFound();
            }

            _bookBL.DeleteBook(id);
            return NoContent();
        }

        // GET: api/books/author/{author}
        [HttpGet("author/{author}")]
        public ActionResult<IEnumerable<Book>> GetBooksByAuthor(string author)
        {
            // Example of filtering by author in BL (if needed)
            var books = _bookBL.GetBooks().FindAll(b => b.Author.ToLower() == author.ToLower());
            if (books.Count == 0)
            {
                return NotFound();
            }
            return books;
        }
    }
}
